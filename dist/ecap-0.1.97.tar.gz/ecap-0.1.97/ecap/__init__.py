from ecap.main import ecap, predict_ecap
