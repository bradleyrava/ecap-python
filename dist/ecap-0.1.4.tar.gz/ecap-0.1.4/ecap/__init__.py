from ecap.main import ecap
from ecap.main import predict_ecap
